import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;
import com.rabbitmq.client.DeliverCallback;

public class Consumer2 {

	private static final String EXCHANGE_NAME = "direct_logs";

	public static void main(String[] argv) throws Exception {
		
		System.out.println("Consumer2 going to start");

		ConnectionFactory factory = new ConnectionFactory();
		factory.setHost("192.168.56.12");
		factory.setPort(5672);
		factory.setUsername("Receiver1");
		factory.setPassword("Receiver1");

		Connection connection = factory.newConnection();
		Channel channel = connection.createChannel();

		channel.exchangeDeclare(EXCHANGE_NAME, "direct");
		String queueName = channel.queueDeclare().getQueue();
		channel.queueBind(queueName, EXCHANGE_NAME, "General");
		channel.queueBind(queueName, EXCHANGE_NAME, "Message2");

		System.out.println(" [*] Waiting for messages. To exit press CTRL+C");

		DeliverCallback deliverCallback = (consumerTag, delivery) -> {
			String message = new String(delivery.getBody(), "UTF-8");
			System.out.println(" [x] Received '" + message + "'");
		};
		
		channel.basicConsume(queueName, true, deliverCallback, consumerTag -> {
		});
	}

}

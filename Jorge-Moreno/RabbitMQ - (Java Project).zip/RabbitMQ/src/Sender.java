import com.rabbitmq.client.ConnectionFactory;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.Channel;

public class Sender {

	private static final String EXCHANGE_NAME = "direct_logs";

	public static void main(String[] argv) throws Exception {
		
		System.out.println("Productor going to start");

		ConnectionFactory factory = new ConnectionFactory();
		factory.setHost("192.168.56.12");
		factory.setPort(5672);
		factory.setUsername("Sender");
		factory.setPassword("Sender");

		try (Connection connection = factory.newConnection(); Channel channel = connection.createChannel()) {
			channel.exchangeDeclare(EXCHANGE_NAME, "direct");

			String message = argv.length < 1 ? "info: Hello World!" : String.join(" ", argv);
		
			while (true) {
				
				channel.basicPublish(EXCHANGE_NAME, "General", null, (message + " General").getBytes("UTF-8"));
				System.out.println(" [x] Sent '" + message + "'"+" General");
				
				channel.basicPublish(EXCHANGE_NAME, "Message1", null, (message + " Message1").getBytes("UTF-8"));
				System.out.println(" [x] Sent '" + message + "'"+" Message1");
				
				channel.basicPublish(EXCHANGE_NAME, "Message2", null, (message + " Message2").getBytes("UTF-8"));
				System.out.println(" [x] Sent '" + message + "'"+" Message2");
				Thread.sleep(1000);
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}

}
